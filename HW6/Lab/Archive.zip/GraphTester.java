

public class GraphTester
{
	public static void main(String[] args)
	{
		int n = 5;
		Graph G = new Graph(n);
		if (fillGraph(G, n, 0))
		{
			for(int i; i<n; ++i)
				System.out.println(G.getAdjList(i));
		}

		n = 9;
		Graph H = new Graph(n);
		if (fillGraph(H, n, 0))
		{
			for(int i; i<n; ++i)
				System.out.println(G.getAdjList(i));
		}

		n = 15;
		Graph J = new Graph(n);
		if (fillGraph(J, n, 0))
		{
			for(int i; i<n; ++i)
				System.out.println(G.getAdjList(i));
		}

	}

	public boolean fillGraph(Graph g, int n, int i)
	{
		boolean success = false;
		i = (i+(n-1)/2)%n;
		g.addEdge(n, i, 1);
		if (i == 0)
			success = true;
		return (success || fillGraph(g, n, i));
	}
}
